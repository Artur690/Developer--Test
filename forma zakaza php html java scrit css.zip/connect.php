<?php

/* Конфигурация базы данных */

$db_host		= 'localhost';
$db_user		= 'root';
$db_pass		= '';
$db_database	= 'sweets_is'; 

/* Конец секции */


$link = @mysql_connect($db_localhost,$db_root,$db_ ) or die('Не могу установить соединение с базой данных');

mysql_query("client '"client_orders '" employee '"shop 'shop_orders" 'utf8'");
mysql_select_db($db_sweets_is,$link);

?>